<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>Kecamatan Tinanggea</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-woox-travel.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
<!--

TemplateMo 580 Woox Travel

https://templatemo.com/tm-580-woox-travel

-->

  </head>

<body>
  <?php require_once 'config.php'; ?>

  <!-- ***** Preloader Start ***** -->
  <!-- <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div> -->
  <!-- ***** Preloader End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="index.html" class="logo">
                        Kecamatan Tinanggea
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                        <li><a id="1" href="index.html" class="active">Home</a></li>
                        <li><a id="2" href="about.html">Topografi</a></li>
                        <li><a id="3" href="deals.html">Batas Wilayah</a></li>
                        <li><a id="4" href="reservation.html">Pertumbuhan penduduk</a></li>
                        <li><a href="reservation.html">Contact</a></li>
                    </ul>   
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>  
  </header>
  <!-- ***** Header Area End ***** -->

  <!-- ***** Main Banner Area Start ***** -->
  <section id="section-1">
    <div class="banner">
      <img src="assets/images/img/menu-bg.jpg" alt="" style="width: 100%; display: block;">
      <div class="static-caption">
        <h2>Selamat Datang</h2>
        <h1>Di desa Tinanggea</h1>
      </div>
    </div>
  </section>
  <!-- ***** Main Banner Area End ***** -->
  
  <div class="visit-country">
    <div class="container">
      <div class="row">
        <div class="col-lg-5">
        </div>
      </div>
      <div class="row">
        <div class="col-lg-8">
          <div class="items">
            <div class="row">
              <div class="col-lg-12">
                <div class="item">
                  <div class="row">
                    <div class="col-lg-4 col-sm-5">
                      <div class="image">
                        <img src="assets/images/img/team/gbr01.jpg" alt="">
                      </div>
                    </div>
                    <div class="col-lg-8 col-sm-7">
                      <div class="right-content">
                        <?php
                          $hasil = mysqli_query($connect, "SELECT judul, uraian_singkat FROM uraian WHERE id_uraian=1");
                          $judul = '';
                          $uraian_singkat = '';
                          if ($hasil) {
                            if ($data = mysqli_fetch_assoc($hasil)) {
                              $judul = $data['judul'];
                              $uraian_singkat = $data['uraian_singkat'];
                            }
                          }
                        ?>
                        <h4><?php echo strip_tags($judul, '<sup><sub><strong><em><b><i><br>'); ?></h4>
                        <p><?php echo strip_tags($uraian_singkat, '<sup><sub><strong><em><b><i><br><p><ul><ol><li><a>'); ?></p>
                        <div class="text-button">
                          <a href="page.php?id=1">Info Selengkapnya</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="item">
                  <div class="row">
                    <div class="col-lg-4 col-sm-5">
                      <div class="image">
                        <img src="assets/images/img/team/gbr02.jpg" alt="">
                      </div>
                    </div>
                    <div class="col-lg-8 col-sm-7">
                      <div class="right-content">
                        <?php
                          $hasil2 = mysqli_query($connect, "SELECT judul, uraian_singkat FROM uraian WHERE id_uraian=2");
                          $judul2 = '';
                          $uraian_singkat2 = '';
                          if ($hasil2) {
                            if ($data2 = mysqli_fetch_assoc($hasil2)) {
                              $judul2 = $data2['judul'];
                              $uraian_singkat2 = $data2['uraian_singkat'];
                            }
                          }
                        ?>
                        <h4><?php echo strip_tags($judul2, '<sup><sub><strong><em><b><i><br>'); ?></h4>
                        <p><?php echo strip_tags($uraian_singkat2, '<sup><sub><strong><em><b><i><br><p><ul><ol><li><a>'); ?></p>
                        <div class="text-button">
                          <a href="page.php?id=2">Info Selengkapnya</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12">
                <div class="item last-item">
                  <div class="row">
                    <div class="col-lg-4 col-sm-5">
                      <div class="image">
                        <img src="assets/images/img/team/gbr03.jpg" alt="">
                      </div>
                    </div>
                    <div class="col-lg-8 col-sm-7">
                      <div class="right-content">
                        <?php
                          $hasil3 = mysqli_query($connect, "SELECT judul, uraian_singkat FROM uraian WHERE id_uraian=3");
                          $judul3 = '';
                          $uraian_singkat3 = '';
                          if ($hasil3) {
                            if ($data3 = mysqli_fetch_assoc($hasil3)) {
                              $judul3 = $data3['judul'];
                              $uraian_singkat3 = $data3['uraian_singkat'];
                            }
                          }
                        ?>
                        <h4><?php echo strip_tags($judul3, '<sup><sub><strong><em><b><i><br>'); ?></h4>
                        <p><?php echo strip_tags($uraian_singkat3, '<sup><sub><strong><em><b><i><br><p><ul><ol><li><a>'); ?></p>
                        <div class="text-button">
                          <a href="page.php?id=3">Info Selengkapnya</a>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-lg-12">
                <ul class="page-numbers">
                  <li><a href="#"><i class="fa fa-arrow-left"></i></a></li>
                  <li><a href="#">1</a></li>
                  <li class="active"><a href="#">2</a></li>
                  <li><a href="#">3</a></li>
                  <li><a href="#"><i class="fa fa-arrow-right"></i></a></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4">
          <div class="side-bar-map">
            <div class="row">
              <div class="col-lg-12">
                <div id="map" style="border-radius: 23px; overflow: hidden;">
                  <div class="embed-map-responsive"><div class="embed-map-container"><iframe class="embed-map-frame" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=400&height=530&hl=en&q=tinanggea&t=k&z=15&ie=UTF8&iwloc=B&output=embed"></iframe><a href="https://sprunkiretake.net" style="font-size:2px!important;color:gray!important;position:absolute;bottom:0;left:0;z-index:1;max-height:1px;overflow:hidden">sprunki retake</a></div><style>.embed-map-responsive{position:relative;text-align:right;width:100%;height:0;padding-bottom:132.5%;}.embed-map-container{overflow:hidden;background:none!important;width:100%;height:100%;position:absolute;top:0;left:0;}.embed-map-frame{width:100%!important;height:100%!important;position:absolute;top:0;left:0;}</style></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="call-to-action">
    <div class="container">
      <div class="row">
        <div class="col-lg-8">
          <h2>Are You Looking To Travel ?</h2>
          <h4>Make A Reservation By Clicking The Button</h4>
        </div>
        <div class="col-lg-4">
          <div class="border-button">
            <a href="reservation.html">Book Yours Now</a>
          </div>
        </div>
      </div>
    </div>
  </div>

  <footer>
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <p>Copyright © 2036 <a href="#">WoOx Travel</a> Company. All rights reserved. 
          <br>Design: <a href="https://templatemo.com" target="_blank" title="free CSS templates">TemplateMo</a></p>
        </div>
      </div>
    </div>
  </footer>


  <!-- Scripts -->
  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/wow.js"></script>
  <script src="assets/js/tabs.js"></script>
  <script src="assets/js/popup.js"></script>
  <script src="assets/js/custom.js"></script>

  <script>
    function bannerSwitcher() {
      next = $('.sec-1-input').filter(':checked').next('.sec-1-input');
      if (next.length) next.prop('checked', true);
      else $('.sec-1-input').first().prop('checked', true);
    }

    var bannerTimer = setInterval(bannerSwitcher, 5000);

    $('nav .controls label').click(function() {
      clearInterval(bannerTimer);
      bannerTimer = setInterval(bannerSwitcher, 5000)
    });
  </script>

  </body>

</html>
