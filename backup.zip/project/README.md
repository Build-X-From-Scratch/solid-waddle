# laughing-eureka

# Introduction

laughing eureka is a project ..

# Develoment SetUp

## install xampp

use the command for installing xampp
```bash

```

but if your use arch based,you can immediately install use AUR package with command
```bash
yay -S xampp
```